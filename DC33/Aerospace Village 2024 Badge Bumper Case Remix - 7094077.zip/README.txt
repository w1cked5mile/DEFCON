Aerospace Village 2024 Badge Bumper Case Remix by darkgrue on Thingiverse: https://www.thingiverse.com/thing:7094077

Summary:
Remix of the Bumper Case on the 2024 Aerospace Village badge GitHub.This fixes numerous errors in the original file: realigns the RF cutout, adds the missing USB-C cutout, adds a cutout for the SOA shroud, adds a relief cut for an inserted MicroSD card, a cutout to access the reset and boot buttons on the back, and adds additional support for the PCB on the lower edge.Aerospace Village DC 32 page2024 Aerospace Village Badge on Tindie